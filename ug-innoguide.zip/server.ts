import express from "express";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import Database from "better-sqlite3";
import * as cheerio from "cheerio";
import TurndownService from "turndown";

// Load environment variables from .env.example since .env is not persisting
const result = dotenv.config({ path: path.resolve(process.cwd(), ".env.example"), override: true });

// Initialize Database
const db = new Database("knowledge_base.db");
db.exec(`
  CREATE TABLE IF NOT EXISTS content (
    url TEXT PRIMARY KEY,
    title TEXT,
    markdown TEXT,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

const turndownService = new TurndownService();

const SOURCES = [
  "https://rid.ug.edu.gh/news",
  "https://orid1.ug.edu.gh/news/",
  "https://nmimr.ug.edu.gh/",
  "https://www.waccbip.org/news",
  "https://biotech.ug.edu.gh/",
  "https://dig.ug.edu.gh/",
  "https://www.iast.ug.edu.gh/",
  "https://www.ug.edu.gh/academics/centres-institutes",
  "https://ugms.ug.edu.gh/",
  "https://ugmedicalcentre.org/",
  "https://chs.ug.edu.gh/",
  "https://pharmacy.ug.edu.gh/",
  "https://sbahs.ug.edu.gh/",
  "https://www.ug.edu.gh/academics/departments",
  "https://www.ug.edu.gh/research/research-centres",
  "https://www.ug.edu.gh/academics/colleges",
  "https://www.ug.edu.gh/news-events",
  "https://rips.ug.edu.gh/",
  "https://isser.ug.edu.gh/",
  "https://www.ug.edu.gh/about-ug/overview"
];

async function crawlUrl(url: string) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000); // 15s timeout

  try {
    console.log(`Crawling ${url}...`);
    const response = await fetch(url, {
      headers: { 
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
      },
      signal: controller.signal,
      // @ts-ignore - node-fetch/undici specific to ignore TLS errors for known problematic but safe sites
      dispatcher: url.includes('ug.edu.gh') ? undefined : undefined 
    });
    
    clearTimeout(timeoutId);

    if (!response.ok) {
      if (response.status === 404) {
        console.warn(`Skipping 404: ${url}`);
        return;
      }
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const html = await response.text();
    const $ = cheerio.load(html);
    
    // Remove script, style, and nav elements to clean up text
    $('script, style, nav, footer, header').remove();
    
    const title = $('title').text() || url;
    const contentHtml = $('body').html() || "";
    const markdown = turndownService.turndown(contentHtml);
    
    // Store in DB
    const upsert = db.prepare(`
      INSERT INTO content (url, title, markdown, last_updated)
      VALUES (?, ?, ?, CURRENT_TIMESTAMP)
      ON CONFLICT(url) DO UPDATE SET
        title=excluded.title,
        markdown=excluded.markdown,
        last_updated=CURRENT_TIMESTAMP
    `);
    upsert.run(url, title, markdown.substring(0, 50000)); // Cap size
    console.log(`Successfully updated cache for ${url}`);
  } catch (error) {
    console.error(`Failed to crawl ${url}:`, error);
  }
}

async function startBackgroundCrawler() {
  console.log("Starting initial crawl...");
  for (const url of SOURCES) {
    await crawlUrl(url);
    // Add a small delay between crawls to be respectful
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  
  // Refresh every 6 hours
  setInterval(async () => {
    console.log("Starting periodic refresh crawl...");
    for (const url of SOURCES) {
      await crawlUrl(url);
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  }, 6 * 60 * 60 * 1000);
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Start crawler in background
  startBackgroundCrawler().catch(console.error);

  // Gemini API Route
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, history } = req.body;
      
      let apiKey = process.env.GEMINI_API_KEY;

      // Fallback: If it's the placeholder, try to find the real one in .env.example
      if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
        try {
          const envExample = fs.readFileSync(path.resolve(process.cwd(), ".env.example"), "utf-8");
          const match = envExample.match(/GEMINI_API_KEY=["']?([^"'\s]+)["']?/);
          if (match && match[1] && match[1] !== "MY_GEMINI_API_KEY") {
            apiKey = match[1];
            console.log("Fallback: Found API key in .env.example");
          }
        } catch (e) {
          console.error("Fallback failed:", e);
        }
      }

      // In AI Studio, the key is injected. If it's the placeholder or missing, we fail gracefully with instructions.
      if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
        return res.status(401).json({ 
          error: "Gemini API key is missing or not configured. Please go to the 'Secrets' panel in the Google AI Studio sidebar and add a secret named 'GEMINI_API_KEY' with your valid API key." 
        });
      }

      const ai = new GoogleGenAI({ apiKey });
      
      // Fetch relevant context from DB with optimized keyword extraction
      const keywords = message.toLowerCase().split(/\W+/).filter((w: string) => w.length > 3).slice(0, 5);
      let contextItems: any[] = [];
      
      if (keywords.length > 0) {
        const placeholders = keywords.map(() => "markdown LIKE ?").join(" OR ");
        const query = db.prepare(`SELECT title, markdown, url FROM content WHERE ${placeholders} LIMIT 3`);
        contextItems = query.all(keywords.map((k: string) => `%${k}%`));
      } else {
        contextItems = db.prepare(`SELECT title, markdown, url FROM content ORDER BY last_updated DESC LIMIT 2`).all();
      }

      const cachedContext = contextItems.map(item => 
        `[${item.title}](${item.url}): ${item.markdown.substring(0, 1500)}`
      ).join("\n---\n");

      // Format history for Gemini
      const contents = history.map((msg: any) => ({
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: msg.content }]
      }));

      // Add current message
      contents.push({ role: "user", parts: [{ text: message }] });

      // Set headers for streaming and disable buffering for Nginx
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      res.setHeader('X-Accel-Buffering', 'no');
      res.setHeader('X-Content-Type-Options', 'nosniff');
      res.flushHeaders();

      const responseStream = await ai.models.generateContentStream({
        model: "gemini-3-flash-preview",
        contents: contents,
        config: {
          systemInstruction: `You are InnoGuide, an expert assistant for the University of Ghana.
          Use this cached context for speed:
          ${cachedContext}
          
          If more info is needed, use the urlContext tool with these URLs: ${SOURCES.join(", ")}
          
          Be concise and professional. Use Markdown.`,
          tools: [{ urlContext: {} }],
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
        }
      });

      for await (const chunk of responseStream) {
        const text = chunk.text;
        if (text) {
          // Use a more compact key 't' for faster serialization/deserialization
          res.write(`data: ${JSON.stringify({ t: text })}\n\n`);
        }
      }

      res.write('data: [DONE]\n\n');
      res.end();
    } catch (error: any) {
      console.error("Gemini Error:", error);
      if (res.headersSent) {
        if (!res.writableEnded) {
          res.write(`data: ${JSON.stringify({ error: error.message || "Internal Server Error" })}\n\n`);
          res.end();
        }
        return;
      }
      if (error.message?.includes("API key not valid") || error.message?.includes("API_KEY_INVALID")) {
        return res.status(401).json({ error: "Invalid API key." });
      }
      res.status(500).json({ error: error.message || "Internal Server Error" });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
